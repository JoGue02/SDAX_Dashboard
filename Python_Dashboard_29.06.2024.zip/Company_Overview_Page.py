import streamlit as st
import pandas as pd
import os
import matplotlib.pyplot as plt

# Directory where the Excel files are stored
excel_dir = 'C:/Users/Joni/Desktop/Financial Data/SDAX/Companies'

# List of all available Excel files
excel_files = [f for f in os.listdir(excel_dir) if f.endswith('.xlsx')]

# Extract company names from the filenames
company_list = [os.path.splitext(f)[0] for f in excel_files]

# Create the Streamlit application
st.title("Company Information")

# Search bar to select the company
selected_company = st.selectbox("Choose a company:", company_list)

# Load and display the selected company's information
if selected_company:
    # Find the corresponding Excel file
    excel_file_selected = os.path.join(excel_dir, f"{selected_company}.xlsx")

    # Load the specific sheet "Valuation" for the selected company
    df_selected = pd.read_excel(excel_file_selected, sheet_name='Valuation', header=None)

    try:
        # Extract the required data from specific cells for the selected company
        name_selected = df_selected.iloc[1, 1]  # B2
        headquarters_selected = df_selected.iloc[3, 1]  # B4
        industry_selected = df_selected.iloc[4, 1]  # B5
        enterprise_value_selected = df_selected.iloc[16, 1]  # B17
        market_cap_selected = df_selected.iloc[19, 1]  # B20
        stock_price_selected = df_selected.iloc[22, 1]  # B23
        last_update_selected = df_selected.iloc[14, 1]  # B15

        # Display the information for the selected company
        st.subheader(f"Information for {selected_company}:")
        st.write(f"**Name:** {name_selected}")
        st.write(f"**Headquarters:** {headquarters_selected}")
        st.write(f"**Industry:** {industry_selected}")
        st.write(f"**Enterprise Value:** {enterprise_value_selected} million EUR")
        st.write(f"**Market Capitalization:** {market_cap_selected} million EUR")
        st.write(f"**Stock Price:** {stock_price_selected} EUR")
        st.write(f"*Last Update:* {last_update_selected}")

    except IndexError as e:
        st.error("The Excel file for the selected company does not have the expected number of rows and columns. Please check the file.")
        st.write(f"Error details: {e}")
    except ValueError as e:
        st.error("Error in processing the Excel file for the selected company. Please ensure the data format is correct.")
        st.write(f"Error details: {e}")

    # Load the specific sheet "Financial Summary" for the selected company
    df_financial = pd.read_excel(excel_file_selected, sheet_name='Financial Summary', header=None)

    try:
        # Extract the relevant data for Revenue, Gross Profit, and EBITDA from the sheet
        years = df_financial.iloc[10, 1:8].values  # B11 to H11
        years = [str(int(year)) for year in years]  # Convert years to strings
        revenue = df_financial.iloc[16, 1:8].values  # B17 to H17
        gross_profit = df_financial.iloc[17, 1:8].values  # B18 to H18
        ebitda = df_financial.iloc[19, 1:8].values  # B20 to H20

        # Ensure that there are no NaN values in the data
        if any(pd.isna(years)) or any(pd.isna(revenue)) or any(pd.isna(gross_profit)) or any(pd.isna(ebitda)):
            st.error("The Financial Summary sheet contains NaN values. Please check the data.")
        else:
            # Sort data by years to ensure correct order
            data = list(zip(years, revenue, gross_profit, ebitda))
            data.sort(key=lambda x: x[0])
            sorted_years, sorted_revenue, sorted_gross_profit, sorted_ebitda = zip(*data)

            # Plot the data
            st.subheader("Financial Performance (2017-2023)")
            fig, ax = plt.subplots()
            ax.bar(sorted_years, sorted_revenue, label='Revenue (Million EUR)')
            ax.bar(sorted_years, sorted_gross_profit, label='Gross Profit (Million EUR)', bottom=sorted_revenue)
            ax.bar(sorted_years, sorted_ebitda, label='EBITDA (Million EUR)', bottom=[r + g for r, g in zip(sorted_revenue, sorted_gross_profit)])
            ax.set_title("Revenue, Gross Profit, and EBITDA Over Time")
            ax.set_ylabel("Amount (Million EUR)")
            ax.set_xlabel("Year")
            ax.legend()
            ax.tick_params(axis='x', rotation=45)  # Rotate X-axis labels
            st.pyplot(fig)

    except IndexError as e:
        st.error("The Excel file for the selected company does not have the expected data in the Financial Summary sheet. Please check the file.")
        st.write(f"Error details: {e}")
    except ValueError as e:
        st.error("Error in processing the Financial Summary sheet for the selected company. Please ensure the data format is correct.")
        st.write(f"Error details: {e}")

    # Load the specific sheet "Balance Sheet" for the selected company
    df_balance = pd.read_excel(excel_file_selected, sheet_name='Balance Sheet', header=None)

    try:
        # Extract the relevant data for Capital Structure
        equity = df_balance.iloc[139, 1]  # B140
        long_term_debt = df_balance.iloc[111, 1]  # B112
        short_term_debt = df_balance.iloc[107, 1]  # B108

        # Ensure that there are no NaN values in the data
        if pd.isna(equity) or pd.isna(long_term_debt) or pd.isna(short_term_debt):
            st.error("The Balance Sheet sheet contains NaN values. Please check the data.")
        else:
            # Plot the Capital Structure as a pie chart
            st.subheader("Capital Structure")
            labels = ['Equity', 'Long Term Debt', 'Short Term Debt']
            sizes = [equity, long_term_debt, short_term_debt]
            fig, ax = plt.subplots()
            ax.pie(sizes, labels=labels, autopct='%1.1f%%', startangle=90)
            ax.axis('equal')  # Equal aspect ratio ensures that pie is drawn as a circle.
            st.pyplot(fig)

    except IndexError as e:
        st.error("The Excel file for the selected company does not have the expected data in the Balance Sheet sheet. Please check the file.")
        st.write(f"Error details: {e}")
    except ValueError as e:
        st.error("Error in processing the Balance Sheet sheet for the selected company. Please ensure the data format is correct.")
        st.write(f"Error details: {e}")
